import pynytimes
from pynytimes import NYTAPI
import requests
import json
import streamlit as st
st.title("NY Times Article Search")
st.write("Lists the 10 most recent article snippets and links from the New York Times based on a key word search")
def article_data(query, apikey):
    apistring = "https://api.nytimes.com/svc/search/v2/articlesearch.json?q=" + str(query) + "&api-key=" + apikey
    response = requests.get(apistring)
    data = response.json()
    outputs = data["response"]["docs"]
    article_list = []
    for art in outputs: 
        article_list.append((art["web_url"], art["snippet"]))
    return article_list


def main():
    apikey = "tIDbb3dcUq7qoXbUHhCZ7szsERyvRVhb"
    nytapi = pynytimes.NYTAPI(apikey, parse_dates=True)
    query = st.text_input("Enter a search key word: ")
    st.divider()
    articles = None
    if query:
        articles = article_data(query, apikey)
        for index, (url, snip) in enumerate(articles):
            st.write(str(index+1) + ". " + snip + " [link](%s)" % url)



if __name__ == "__main__":
    main()